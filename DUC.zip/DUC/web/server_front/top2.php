<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		echo "<script> location.href = 'log_in.php'</script>";

	}
?>
	<html>

	<head>
   	 	<title>Welcome admin!</title>
    		<meta charset="utf-8">
    		<meta name="viewport" content="width=device-width, initial-scale=1">
    		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	</head>


	<body>
   	
	<script src="https://www.gstatic.com/firebasejs/5.10.0/firebase.js"></script>
        <script>
        // Initialize Firebase
            var config = {
        	apiKey: "AIzaSyBWU26tBSECLWyxSdPTHwiGfNFfUwpGowQ",
        	authDomain: "signindemo-f56a8.firebaseapp.com",
        	databaseURL: "https://signindemo-f56a8.firebaseio.com",
       	 	projectId: "signindemo-f56a8",
        	storageBucket: "signindemo-f56a8.appspot.com",
        	messagingSenderId: "136499857355"
    	};
    	firebase.initializeApp(config);
	

	//document.querySelector('img').src = ;


	</script>
	
    	<nav class="navbar navbar-expand-lg bg-dark justify-content-center">
        <!--	<a class="navbar-brand" href="http://www.du.ac.bd/"><img src="" alt="Logo"></a> -->
        	
	 	<ul class="nav ">
			<li class="nav-item"> <a class="nav-link" href="home.php">Home</a> </li>
        		<li class="nav-item dropdown">
                		<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Departments</a>
                		<div class="dropdown-menu">
                			<a class="dropdown-item" href="science_dept.php">Science faculty</a>
                    			<a class="dropdown-item" href="commerce_dept.php">Commerce faculty</a>
                    			<a class="dropdown-item" href="arts_dept.php">Arts faculty</a>
                		</div>
            		</li>

	            	<li class="nav-item"> <a class="nav-link" href="offices.php">Offices</a> </li>
	            	<li class="nav-item"> <a class="nav-link" href="halls.php">Halls</a> </li>
	            	<li class="nav-item"> <a class="nav-link" href="clubs.php">Clubs</a> </li>
	            	<li class="nav-item"> <a class="nav-link" href="transports.php">Transports</a> </li>
	            	<li class="nav-item"> <a class="nav-link" href="#">Exciting Places</a> </li>
	            
            		<li class="nav-item dropdown">
	                	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Calendar</a>
	                	<div class="dropdown-menu">
	                    		<a class="dropdown-item" href="calendar.php">General calendar</a>
	                    		<a class="dropdown-item" href="#">Specific calendar</a>
	                    	</div>
	            	</li>

	           	<li class="nav-item dropdown">
	                	<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"> Governing Body </a>
	                	<div class="dropdown-menu">
	                    	<a class="dropdown-item" href="#"> Deans of Faculties</a>
	                    	<a class="dropdown-item" href="#">Editorial Committee</a>
	                    	<a class="dropdown-item" href="#">Implementation Committee</a>
	                	</div>
	            	</li>
			<li class="nav-item"> <a class="nav-link" href="admins.php">Admins</a> </li>
	            	<li class="nav-item"> <a class="nav-link" href="../server_back/log_out.php">Log out</a> </li>
	            

	        </ul>
	</nav>  
	

