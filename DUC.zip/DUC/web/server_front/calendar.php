<?php include '../server_back/connection.php' ;?>
<?php include 'top.php';?>

<script>
	document.title = "General calendar";
</script>
<div class = "container-fluid">
	<table class = "table table-bordered table-dark table-striped table-hover">
	<thead>
	<tr>
		<th> ID</th>
		<th> Event name</th>
		<th> Description</th>
		<th> Date</th>


	</tr>
	<tbody>
		<?php
			$query = "select * from calendar";
			$result = mysqli_query($connection,$query);

			while($row = mysqli_fetch_row($result))
			{
		?>

		<tr>
			<td>  <?php echo $row[0]; ?> </td>
			<td>  <?php echo $row[1]; ?> </td>
			<td>  <?php echo $row[2]; ?> </td>
			<td>  <?php echo $row[3]; ?> </td>
		</tr>

		<?php } ?>

	</tbody>
	</table>
</div>


<div class="container-fluid">
	<form  class="form-inline" action="../server_back/calendar/insert_calendar.php" method="post">

		<input type="text" name="id" placeholder="Enter ID">
		<input type="text" name="name" placeholder="Enter name">
		<input type="text" name="description" placeholder="Enter Description">
		<input type="text" name="date" placeholder="Enter date">

		<button class="btn btn-primary" type="submit">Insert</button>

	</form>

</div>


<div class="container-fluid">
	<form class="form-inline" action="../server_back/calendar/update_calendar.php" method="post">
		<input type="text" name="id" placeholder="Enter ID">
		<input type="text" name="name" placeholder="Enter name">
		<input type="text" name="description" placeholder="Enter Description">
		<input type="text" name="date" placeholder="Enter date">


		<button class="btn btn-warning" type="submit">Update</button>

	</form>

</div>


<div class = "container-fluid">
	<form class="form-inline" action="../server_back/calendar/delete_calendar.php" method="post">
	ID: <input type="text" name="id">
	<input type="hidden" name="table_name" value="calendar">
	<button class="btn btn-danger" type="submit">Delete</button>

	</form>
</div>

<?php include 'bottom.php';?>
