<?php include '../server_back/connection.php' ;?>
<?php include 'top.php';?>

<script>
	document.title = "Halls";
</script>
<div class = "container-fluid">
	<table class = "table table-bordered table-dark table-striped table-hover">
	<thead>
	<tr>
		<th> ID</th>
		<th> Name</th>
		<th> Description</th>
		<th> Establishement year</th>
		<th> Longitude</th>
		<th> Latitude</th>

	</tr>
	<tbody>
		<?php
			$query = "select * from hall";
			$result = mysqli_query($connection,$query);

			while($row = mysqli_fetch_row($result))
			{
		?>

		<tr>
			<td>  <?php echo $row[0]; ?> </td>
			<td>  <?php echo $row[1]; ?> </td>
			<td>  <?php echo $row[2]; ?> </td>
			<td>  <?php echo $row[3]; ?> </td>
			<td>  <?php echo $row[5]; ?> </td>
			<td>  <?php echo $row[6]; ?> </td>

		</tr>

		<?php } ?>

	</tbody>
	</table>
</div>


<div class="container-fluid">
	<form  class="form-inline" action="../server_back/hall/insert_hall.php" method="post">

		<input type="text" name="id" placeholder="Enter ID">
		<input type="text" name="name" placeholder="Enter name">
		<input type="text" name="description" placeholder="Enter description">
		<input type="text" name="year" placeholder="Establishement Year">
		<input type="text" name="latitude" placeholder="Latitude">
		<input type="text" name="longitude" placeholder="Longitude">

		<input type="file" value="Select image" id="fileButton"/>
       		<!-- 	<progress value="0" max="100" id="uploader">%0</progress> -->
	    	<input type="hidden" name="img_url" id="img_url" >



	<script>

   		var fileButton = document.getElementById('fileButton');
    	var uploader = document.getElementById('uploader');
    	fileButton.addEventListener('change', function(e) {

			//get file
      var file = e.target.files[0];

      //create storage ref
      var storageRef = firebase.storage().ref('DU_images/'+ file.name);

      //upload files
      var task = storageRef.put(file);

      //update progress bar
      task.on('state_changed',function progress(snapshot)
        {
            //var percentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            //uploader.value = percentage;
        },

        function error(err)
        {

        },

        function complete()
        {
            //var resultURL = storageRef.fullPath;

            storageRef.getDownloadURL().then(function(url) {
            var test = url;
            alert(test);

            //document.querySelector('img').src = test;
            document.getElementById('img_url').value = url;

        }).catch(function(error) {

         });

			 });
	});

	</script>


	<button class="btn btn-primary" type="submit">Insert</button>


	</form>

</div>


<div class="container-fluid">
	<form class="form-inline" action="../server_back/hall/update_hall.php" method="post">
	ID: <input type="text" name="id">
	&nbsp; Name: <input type= "text" name="name">
	&nbsp; Description: <input type="text" name="description">
	&nbsp; Year:<input type="text" name="year" placeholder="Establishement Year">
	&nbsp; Latitude:<input type="text" name="latitude" placeholder="Latitude">
	&nbsp; Longitude:<input type="text" name="longitude" placeholder="Longitude">

	<button class="btn btn-warning" type="submit">Update</button>

	</form>

</div>


<div class = "container-fluid">
	<form class="form-inline" action="../server_back/hall/delete_hall.php" method="post">
	ID: <input type="text" name="id">
	<input type="hidden" name="table_name" value="departments">
	<button class="btn btn-danger" type="submit">Delete</button>

	</form>
</div>

<?php include 'bottom.php';?>
