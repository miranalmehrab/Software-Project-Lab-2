<?php include 'top.php'; ?>

<div class="jumbotron text-center">
	<h1>The following are the supported actions</h1> <br/> <br/>
	<h5>See the recent data in the tables</h5>
	<h5>Insert new data in the table</h5>
	<h5>Update existing data in the table</h5>
	<h5>Delete existing data in the table</h5>

<div>

<?php include 'bottom.php'; ?>
