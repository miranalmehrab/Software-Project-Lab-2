<?php
	$user = "root2";
	$password = "123password";
	$serverName = "localhost";
	$db = "DUC";

	$connection = mysqli_connect($serverName, $user, $password ,$db);
?>
