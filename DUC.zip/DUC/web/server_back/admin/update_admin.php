<?php include '../connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$password = $_POST['password'];


	$query = "update admin set userName='$name',password='$password' where id='$id'";

	if(!mysqli_query($connection, $query))
	{
		echo "Data not updated!";
	}
	else
	{
		echo "Data updated  succcessfully!";
	}


?>
