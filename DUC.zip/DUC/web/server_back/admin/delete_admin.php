<?php include '../connection.php'; ?>
<?php
	$id = $_POST['id'];

	$query = "delete from admin where id=$id";
	if(!mysqli_query($connection, $query))
	{
		echo "Data not deleted";
	}
	else
	{
		echo "Data deleted successfully !";
	}


?>
