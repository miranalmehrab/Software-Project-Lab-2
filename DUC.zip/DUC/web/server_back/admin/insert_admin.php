<?php include '../connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$password = $_POST['password'];

	$query = "insert into admin (id,userName,password) values('$id','$name','$password')";

	if(!mysqli_query($connection, $query))
	{
		echo "Data not inserted!";
	}
	else
	{
		echo "Data inserted  succcessfully!";
	}


?>
