<?php include '../connection.php'; ?>
<?php
	$id = $_POST['id'];
	$table_name = $_POST['table_name'];

	$query = "delete from calendar where id=$id";
	if(!mysqli_query($connection, $query))
	{
		echo "Data not deleted";
	}
	else
	{
		echo "Data deleted successfully !";
	}


?>
