<?php include '../connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$description = $_POST['description'];
	$date = $_POST['date'];

	$query = "insert into calendar (id,name,description,date) values('$id','$name','$description','$date')";

	if(!mysqli_query($connection, $query))
	{
		echo "Data not inserted!";
	}
	else
	{
		echo "Data inserted  succcessfully!";
	}


?>
