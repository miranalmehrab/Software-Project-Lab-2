<?php include '../connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$description = $_POST['description'];
	$date = $_POST['date'];

	$query = "update calender set name='$name',description='$description',date='$date' where id='$id'";

	if(!mysqli_query($connection, $query))
	{
		echo "Data not updated!";
	}
	else
	{
		echo "Data updated  succcessfully!";
	}


?>
