<?php include '../connection.php' ?>
<?php

	$id = $_POST['id'];
	$name = $_POST['name'];
	$description = $_POST['description'];
	$year = $_POST['year'];
	$latitude = $_POST['latitude'];
	$longitude = $_POST['longitude'];
	$img_url = $_POST['img_url'];


	$query = "insert into hall (id,name,description,establishedYear,image,longitude,latitude) values ('$id','$name','$description','$year','$img_url','$longitude','$latitude')";
	if(!mysqli_query($connection, $query))
	{
		echo "Data not inserted!";
		echo "$name";
		echo "$id";
		echo "$table_name";
		echo "$description";
		echo "$img_url";
		echo $connection->error;
	}
	else
	{
		echo "Data inserted succcessfully!";
		

	}


?>
