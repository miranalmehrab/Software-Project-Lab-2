<?php include 'connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$description = $_POST['description'];
	$table_name = $_POST['table_name'];

	$query = "update $table_name set name='$name',description='$description' where id='$id'";
	if(!mysqli_query($connection, $query))
	{
		echo "Data not updated!";
	}
	else
	{
		echo "Data updated succcessfully!";
	}


?>
