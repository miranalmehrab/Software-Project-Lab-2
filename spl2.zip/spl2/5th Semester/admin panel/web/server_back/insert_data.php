<?php include 'connection.php' ?>
<?php
	$id = $_POST['id'];
	$name = $_POST['name'];
	$description = $_POST['description'];
	$faculty_name = $_POST['faculty_name'];
	$table_name = $_POST['table_name'];

	$query = "insert into $table_name (id,name,description,faculty) values ('$id','$name','$description','$faculty_name')";
	if(!mysqli_query($connection, $query))
	{
		echo "Data not inserted!";
		echo "$name";
		echo "$id";
		echo "$table_name";
		echo "$description";
	}
	else
	{
		echo "Data inserted succcessfully!";
	}


?>
