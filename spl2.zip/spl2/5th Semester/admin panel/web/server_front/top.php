<html>

	<head>
   	 	<title>Welcome admin!</title>
    		<meta charset="utf-8">
    		<meta name="viewport" content="width=device-width, initial-scale=1">
    		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	</head>


	<body>
   
    	<nav class="navbar navbar-expand-lg bg-dark justify-content-center">
        	<a class="navbar-brand" href="http://www.du.ac.bd/"><img src="DUC/web/server_front/logo.png"></a>
        	
	 	<ul class="nav ">
			<li class="nav-item"> <a class="nav-link" href="home.php">Home</a> </li>
        		<li class="nav-item dropdown">
                		<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Departments</a>
                		<div class="dropdown-menu">
                			<a class="dropdown-item" href="science_dept.php">Science faculty</a>
                    			<a class="dropdown-item" href="commerce_dept.php">Commerce faculty</a>
                    			<a class="dropdown-item" href="arts_dept.php">Arts faculty</a>
                		</div>
            		</li>

	            <li class="nav-item"> <a class="nav-link" href="#">Offices</a> </li>
	            <li class="nav-item"> <a class="nav-link" href="HomePage.html">Halls</a> </li>
	            <li class="nav-item"> <a class="nav-link" href="#">Clubs</a> </li>
	            <li class="nav-item"> <a class="nav-link" href="#">Buses</a> </li>
	            <li class="nav-item"> <a class="nav-link" href="#">Exciting Places</a> </li>
	            
            
	            <li class="nav-item dropdown">
	                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"> Governing Body </a>
	                <div class="dropdown-menu">
	                    <a class="dropdown-item" href="#"> Deans of Faculties</a>
	                    <a class="dropdown-item" href="#">Editorial Committee</a>
	                    <a class="dropdown-item" href="#">Implementation Committee</a>
	                </div>
	            </li>
	        </ul>
	</nav>
	
