<?php include '../server_back/connection.php' ;?>
<?php include 'top.php';?>

<script>
	document.title = "Arts Departments";
</script>
<div class = "container-fluid">
	<table class = "table table-borderless">
	<thead>
	<tr>
		<th> ID</th>
		<th> Name</th>	
		<th> Description</th>
		<th> Faculty</th>
	</tr>
	<tbody>
		<?php
			$query = "select * from departments where faculty='Arts'";
			$result = mysqli_query($connection,$query);
 
			while($row = mysqli_fetch_row($result))
			{
		?>

		<tr>
			<td>  <?php echo $row[0]; ?> </td>
			<td>  <?php echo $row[1]; ?> </td>
			<td>  <?php echo $row[2]; ?> </td>
			<td>  <?php echo $row[3]; ?> </td>
	
	
		</tr>

		<?php
			}
		?>

	</tbody>
	</table>
</div>
<div class="container-fluid">
	<form action="../server_back/insert_data.php" method="post">
	ID: <input type="text" name="id">
	Name: <input type= "text" name="name">
	Description: <input type="text" name="description">
	<input type="hidden" name="faculty_name" value="Arts">
	<input type="hidden" name="table_name" value="departments">
	<input type="submit" value="Insert">
		
	</form>

</div>
<div class="container-fluid">
	<form action="../server_back/update_data.php" method="post">
	ID: <input type="text" name="id">
	Name: <input type= "text" name="name">
	Description: <input type="text" name="description">
	<input type="hidden" name="table_name" value="departments">
	<input type="submit" value="Update">
		
	</form>

</div>


<div class = "container-fluid">
	<form action="../server_back/delete_data.php" method="post">
	ID: <input type="text" name="id">
	<input type="hidden" name="table_name" value="departments">
	<input type="submit" value="Delete">
		
	</form>
</div>

<?php include 'bottom.php';?>
