<?php include 'top.php';?>
<div class="jumbotron text-center">
	<p>Please select links to access the associated pages!</p>
	<p>Four option available to use</P>
	<ul>
		<li>See existing data</li>
		<li>Add new data</li>
		<li>Update existing data</li>
		<li>Delete data</li>
	</ul>
</div>




<?php 	include 'bottom.php'; ?>
