	<div style="height:100px; text-align:center;background-color:cadetblue; padding-top:40px;">     
	       	<b>All rights reserved, copyright &copy; <b>DUC Team</b></b>
	</div>
	   
	</body>

</html>
