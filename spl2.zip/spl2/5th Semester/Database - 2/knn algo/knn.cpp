#include <bits/stdc++.h>
#include "Data.h"
#include "ReadFile.h"
#include "Accuracy.h"
#include "CalculateData.h"

using namespace std;

int main()
{
	int knnNumber = 3;
	vector <Data> v;

	v = readFromFile(v);
	v = calculation(v,knnNumber);

	return 0;
}