#include <bits/stdc++.h>

using namespace std;

struct Calculation
{
	float distance;
	int calculatedClass;
};

struct Data
{
	int x,y,z;
	int actualClass;
	Calculation calc;
};
