#include <bits/stdc++.h>

using namespace std;

float avgDistance =0.0;

bool compareDistance(Calculation obj1,Calculation obj2) //Function pointer for vector sorting
{
	return (obj1.distance < obj2.distance);
}


bool checkContinuation(bool *isPicked,int size)
{
	for(int i=0;i<size;i++) if(isPicked[i]==false) return false;
	return true;
}


int returnClass(vector <Calculation> distanceVector,int knnNumber)  //Decides in which class the data belongs against the calculation of distance.
{
	int choseOne =0;
	int choseTwo =0;
	float distance =0.0;

	sort(distanceVector.begin(),distanceVector.end(),compareDistance);

	for(int i=0;i<knnNumber;i++)
	{
		distance += distanceVector[i].distance;
		if(distanceVector[i].calculatedClass == 1) choseOne++;
		else if(distanceVector[i].calculatedClass == 2) choseTwo++;
	}

	avgDistance = distance/knnNumber;

	if(choseOne>choseTwo) return 1;
	else if (choseTwo>choseOne)return 2;
	else 
	{
		if( rand()%2 == 1) return 1;
		else return 2;
	}
}



int catculateClass(Data data,vector <Data> v,int limit,int knnNumber,int dataItemNumber)
{
	int temp;
	Calculation dist;
	vector <Calculation> distanceVector;

	for(int i=0;i<v.size();i++)
	{
		if(i>(limit-dataItemNumber-1) && i<(limit+1)) continue;

		dist.distance = (data.x-v[i].x)*(data.x-v[i].x) + (data.y-v[i].y)*(data.y-v[i].y) + (data.z-v[i].z)*(data.z-v[i].z);
		dist.distance = sqrt(dist.distance);
		dist.calculatedClass = v[i].actualClass;
		
		distanceVector.push_back(dist);
		temp++;
	}

	return returnClass(distanceVector,knnNumber);
}


int catculateClass(Data data,vector <Data> v,vector <int> picked,int knnNumber)
{
	int temp;
	Calculation dist;
	vector <Calculation> distanceVector;

	for(int i=0;i<v.size();i++)
	{
		bool isPicked = false;
		for(int j=0;j<picked.size();j++)
		{
			if(i == picked[j])
			{
				isPicked = true;
				break;
			}
		} 

		if(isPicked) continue;

		dist.distance = (data.x-v[i].x)*(data.x-v[i].x) + (data.y-v[i].y)*(data.y-v[i].y) + (data.z-v[i].z)*(data.z-v[i].z);
		dist.distance = sqrt(dist.distance);
		dist.calculatedClass = v[i].actualClass;
		
		distanceVector.push_back(dist);
		temp++;
	}

	return returnClass(distanceVector,knnNumber);
}


int getLimit(int pick,int dataItemNumber, vector <Data> v)
{
	int limit =0;
	if(pick==9) limit = v.size();
	else limit = pick*dataItemNumber+dataItemNumber+1;
	
	return limit;
}

/*
vector <Data>  calculation(vector <Data> v,int knnNumber)  //Check random 10% of the data set with the remaining 90% of data.
{
	int limit =0;
	int pick = 0;
	bool isPicked[10];
	bool shouldLeave = true;

	int dataItemNumber = round(v.size()/10.00);
	srand(100);

	for(int i=0;i<10;i++) isPicked[i] = false;

	vector<float> rv;
	while(1)
	{
		shouldLeave = true;
		pick = rand()%10;
		
		if(isPicked[pick]==true) continue;
		else isPicked[pick] = true;
		
		limit = getLimit(pick,dataItemNumber, v);
		pick = pick*dataItemNumber;
		
		for(int i=pick;i<limit;i++)
		{
			v[i].calc.calculatedClass = catculateClass(v[i],v,limit,knnNumber,dataItemNumber);
			v[i].calc.distance = avgDistance;
			avgDistance = 0.0;
		}

		rv.push_back(accuracy(v,pick,limit));

		if(checkContinuation(isPicked,10)) break;
	}

	float rvTemp =0.0;
	for(int i=0;i<rv.size();i++) rvTemp+=rv[i];
	rvTemp = rvTemp/rv.size(); 
	
	cout << "Over all accuracy is: "<<rvTemp<<endl;


	return v;

}
*/

/*
vector <Data>  calculation(vector <Data> v,int knnNumber)  //Check random 10% of the data set with the remaining 90% of data.
{
	int limit =0;
	int pick = 0;
	bool isPicked[10];
	bool shouldLeave = true;

	int dataItemNumber = round(v.size()/10.00);
	srand(10);

	for(int i=0;i<10;i++)
	{
		v = shuffleData(v);
		pick = rand()%10;
		limit = getLimit(pick,dataItemNumber, v);
		pick = pick*dataItemNumber;
		
		for(int j=pick;j<limit;j++)
		{
			v[j].calc.calculatedClass = catculateClass(v[j],v,limit,knnNumber,dataItemNumber);
			v[j].calc.distance = avgDistance;
			avgDistance = 0.0;
		}

		precission(v,pick,limit);
	}
	
	return v;

}
*/

vector <Data>  calculation(vector <Data> v,int knnNumber)  //Check random 10% of the data set with the remaining 90% of data.
{
	int limit =0;
	int pick = 0;
	bool isPicked[10];
	bool shouldLeave = true;

	int dataItemNumber = round(v.size()/10.00);
	srand(10);

	for(int i=0;i<10;i++)
	{
		v = shuffleData(v);
		
		vector <Data> dv;
		vector <int> picked;

		while(picked.size() != dataItemNumber)
		{
			bool shouldPick = true;
			pick = rand()%v.size();

			for(int k=0;k<picked.size();k++)
			{
				if(picked[k]==pick) 
				{
					shouldPick = false;
					break;
				}
			}

			if(shouldPick)
			{
				dv.push_back(v[pick]);
				picked.push_back(pick);
			}
		}
		
		
		for(int j=0;j<dv.size();j++)
		{
			dv[j].calc.calculatedClass = catculateClass(dv[j],v,picked,knnNumber);
			dv[j].calc.distance = avgDistance;
			avgDistance = 0.0;
		}

		precission(dv);
	}
	
	return v;

}

