#include <bits/stdc++.h>

using namespace std;

void precission(vector <Data> v)
{
	float truePositive =0;
	int trueNegative =0;
	int falsePositive =0;
	int falseNegative =0;

	for(int i=0;i<v.size();i++)
	{
		if(v[i].actualClass ==1 && v[i].calc.calculatedClass==1) ++truePositive;
		else if(v[i].actualClass ==1 && v[i].calc.calculatedClass==2) ++falsePositive;
		else if(v[i].actualClass ==2 && v[i].calc.calculatedClass==1) ++falseNegative;
		else if(v[i].actualClass ==2 && v[i].calc.calculatedClass==2) ++trueNegative;
	}

	cout <<endl;
	cout << "True Positive: " << truePositive <<"		False Positive: " << falsePositive << endl;
	cout << "True Negative: " << trueNegative <<"		False Negative: " << falseNegative << endl <<endl;

	float ratio = (truePositive+trueNegative)/(truePositive+trueNegative+falseNegative+falsePositive);
	float pr = truePositive/(truePositive+falsePositive);
	float recall = truePositive/(truePositive+falseNegative);
	float f_score = (2*pr*recall)/(pr+recall);

	cout << "Accuracy : "<<ratio*100.00<<"%"<<endl;
	cout << "Precission : "<<pr*100.00<<"%"<<endl;	
	cout << "Recall: "<<recall*100.00<<"%"<<endl;
	cout << "f-score: "<<f_score*100.00<<"%"<<endl<<endl;

	cout <<"-----------XXXXXX------------"<<endl;
}


void precission(vector <Data> v,int base,int limit)
{
	float truePositive =0;
	int trueNegative =0;
	int falsePositive =0;
	int falseNegative =0;

	for(int i=base;i<limit;i++)
	{
		if(v[i].actualClass ==1 && v[i].calc.calculatedClass==1) ++truePositive;
		else if(v[i].actualClass ==1 && v[i].calc.calculatedClass==2) ++falsePositive;
		else if(v[i].actualClass ==2 && v[i].calc.calculatedClass==1) ++falseNegative;
		else if(v[i].actualClass ==2 && v[i].calc.calculatedClass==2) ++trueNegative;
	}

	cout <<endl;
	cout << "True Positive: " << truePositive <<"		False Positive: " << falsePositive << endl;
	cout << "True Negative: " << trueNegative <<"		False Negative: " << falseNegative << endl <<endl;

	float ratio = (truePositive+trueNegative)/(truePositive+trueNegative+falseNegative+falsePositive);
	float pr = truePositive/(truePositive+falsePositive);
	float recall = truePositive/(truePositive+falseNegative);
	float f_score = (2*pr*recall)/(pr+recall);

	cout << "Accuracy : "<<ratio*100.00<<"%"<<endl;
	cout << "Precission : "<<pr*100.00<<"%"<<endl;	
	cout << "Recall: "<<recall*100.00<<"%"<<endl;
	cout << "f-score: "<<f_score*100.00<<"%"<<endl<<endl;

	cout <<"-----------XXXXXX------------"<<endl;
	
}

