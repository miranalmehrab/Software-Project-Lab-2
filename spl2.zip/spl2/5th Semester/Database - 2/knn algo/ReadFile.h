#include <bits/stdc++.h>

using namespace std;

int stringToInt(string line) // Converts string to integer
{
	int intData;
	stringstream stream;
	stream << line;
	stream >> intData;
	
	return intData;
}


Data splitLine(string line)  //Splits the input string and return a Data object.
{
	char ch;
	int counter;
	string str;
	Data data;
	vector<int> temp;

	while(counter<=line.size())
	{
		if(ch == ',')
		{
			temp.push_back(stringToInt(str));
			str = "";
		}
		ch = line[counter];
		str = str+ch;
		counter++;
	}

	temp.push_back(stringToInt(str));

	data.x = temp[0];
	data.y = temp[1];
	data.z = temp[2];
	data.actualClass = temp[3];	

	return data;
}


void printInput(vector <Data> v) //Prints the inputs
{
	for(int i=0;i<v.size();i++) cout << v[i].x<<" "<<v[i].y<<" "<<v[i].z<<" "<<v[i].actualClass<<endl;
}


vector<Data> shuffleData(vector <Data> v)  //Shuffles data of the data set
{
	int counter = 0;
	int index = 0;
	Data tempData;

	srand(100);

	while(1)
	{
		index = rand() % v.size();
		if(counter <= index)
		{
			tempData = v[counter];
			v[counter] = v[index];
			v[index] = tempData;
			counter++;
		}
		if(counter >= v.size()) break;
	}

	return v;
}

vector <Data> readFromFile(vector <Data> v)  //Reads input from the file.
{
	string line;
	string fileName = "DataSet.txt";
	ifstream iFile;
	
	//cin >> fileName;
	iFile.open(fileName.c_str());
	if(!iFile.is_open())
	{
		cout <<"Error opening file."<<endl; 
		return v;
	}

	while(!iFile.eof())
	{
		iFile >> line;
		Data data = splitLine(line);
		v.push_back(data);
	}
	iFile.close();
	
	//printInput(v);
	return v;
}
